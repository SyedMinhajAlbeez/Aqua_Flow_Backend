const prisma = require("../prisma/client");
const { updateInvoiceStatus,validatePaymentBeforeCreate } = require("../services/billingService");

exports.createPayment = async (req, res) => {
  try {
    const { invoiceId, tenantId, customerId, amount } = req.body;

    // 1. Validate before creating anything
    await validatePaymentBeforeCreate(invoiceId, amount);

    // 2. Create the payment
    const payment = await prisma.payment.create({
      data: {
        invoiceId,
        tenantId,
        customerId: customerId || null,
        amount: Number(amount),
        paymentDate: new Date(),
        status: "PAID", // or "PENDING" depending on your real flow
        // paymentMethod, notes, collectedByDriverId, etc. if needed
      },
    });

    // 3. Update invoice status & fields
    const updatedInvoice = await updateInvoiceStatus(payment.invoiceId);

    res.status(201).json({
      success: true,
      payment,
      updatedInvoice,
    });
  } catch (err) {
    console.error("Payment creation failed:", err);

    // Friendly error response
    if (err.message.includes("already fully paid") || err.message.includes("exceeds remaining due")) {
      return res.status(400).json({
        success: false,
        message: err.message,
      });
    }

    res.status(500).json({
      success: false,
      message: "Failed to create payment",
      error: err.message,
    });
  }
};
