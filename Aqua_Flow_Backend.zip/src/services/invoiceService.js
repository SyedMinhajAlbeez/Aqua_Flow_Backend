const prisma = require("../prisma/client");
const { updateInvoiceStatus } = require("../services/billingService");
/**
 * Generate or update monthly invoice for a company (tenant)
 * Supports:
 * - Mid-period tariff changes
 * - REUSABLE: tiered pricePerUnit
 * - NON_REUSABLE: tiered percentage of subtotal (based on total qty sold)
 */
async function generateInvoiceForCompany(companyId, periodStart, periodEnd) {
  return prisma.$transaction(async (tx) => {
    // 1. Check for existing invoice first (before doing any calculations)
    const existingInvoice = await tx.invoice.findFirst({
      where: { 
        companyId, 
        periodStart, 
        periodEnd 
      },
      include: {
        payments: {
          where: { status: "PAID" },
        },
      },
    });

    // 2. Prevent regenerating paid invoices
    if (existingInvoice) {
      const totalPaid = existingInvoice.payments.reduce(
        (sum, p) => sum + Number(p.amount || 0),
        0
      );
      const totalAmount = Number(existingInvoice.totalAmount || 0);
      
      if (totalPaid >= totalAmount || existingInvoice.billingStatus === "PAID") {
        // Return existing invoice without regeneration
        const invoiceWithDetails = await tx.invoice.findUnique({
          where: { id: existingInvoice.id },
          include: {
            lineItems: true,
            payments: {
              where: { status: "PAID" },
            },
            company: {
              select: {
                id: true,
                name: true,
                email: true,
              },
            },
          },
        });
        
        return { 
          message: "Invoice is already paid and cannot be regenerated", 
          invoice: {
            ...invoiceWithDetails,
            totalPaid,
            dueAmount: totalAmount - totalPaid,
          }
        };
      }
    }

    // 3. Fetch all delivered/completed orders in the period
    const orders = await tx.order.findMany({
      where: {
        tenantId: companyId,
        deliveryDate: { gte: periodStart, lte: periodEnd },
        status: { in: ["delivered", "completed"] },
      },
      include: {
        items: {
          include: { product: true },
        },
      },
    });

    if (orders.length === 0) {
      return { message: "No orders in this period", invoice: null };
    }

    // 4. Get all company tariffs (past + current)
    const companyTariffs = await tx.companyTariff.findMany({
      where: { companyId },
      include: { tariff: { include: { slabs: true } } },
      orderBy: { effectiveFrom: "asc" },
    });

    if (companyTariffs.length === 0) {
      throw new Error("No tariff assigned to company");
    }

    // Helper: Get applicable tariff for a specific date
    const getTariffForDate = (date) => {
      return companyTariffs.find((ct) => {
        const from = ct.effectiveFrom || new Date(0);
        const to = ct.effectiveTo || new Date("9999-12-31");
        return date >= from && date <= to;
      })?.tariff;
    };

    // 5. Aggregate totals across ALL orders in the period (for correct tiering)
    let totalReusableQty = 0;
    let totalNonReusableQty = 0;
    let totalNonReusableSubtotal = 0; // Sum of (quantity × unitPrice) for non-reusable items

    const orderItemsByDate = {}; // Group items by delivery date for per-tariff calculation

    for (const order of orders) {
      const tariffDateKey = order.deliveryDate.toISOString().split("T")[0];
      if (!orderItemsByDate[tariffDateKey]) orderItemsByDate[tariffDateKey] = [];

      for (const item of order.items) {
        const isReusable = item.product.isReusable;

        if (isReusable) {
          totalReusableQty += item.quantity;
        } else {
          totalNonReusableQty += item.quantity;
          totalNonReusableSubtotal += Number(item.totalPrice); // or item.quantity * item.unitPrice
        }

        orderItemsByDate[tariffDateKey].push({
          ...item,
          productType: isReusable ? "REUSABLE" : "NON_REUSABLE",
        });
      }
    }

    // 6. Calculate fees using progressive tiering (correct way)
    const calculateTieredFee = (slabs, totalQty, totalSubtotal, isPercentage) => {
      const sortedSlabs = slabs
        .filter((s) => s.productType === (isPercentage ? "NON_REUSABLE" : "REUSABLE"))
        .sort((a, b) => a.fromQty - b.fromQty);

      const lineItems = [];
      let remainingQty = totalQty;

      for (const slab of sortedSlabs) {
        if (remainingQty <= 0) break;

        const slabStart = slab.fromQty;
        const slabEnd = slab.toQty ?? Infinity;
        const qtyInThisSlab = Math.max(0, Math.min(remainingQty, slabEnd - slabStart));

        if (qtyInThisSlab <= 0) continue;

        let amount = 0;
        let baseAmount = 0;

        if (isPercentage) {
          // Pro-rate subtotal proportionally across quantity tiers
          const ratio = totalQty > 0 ? qtyInThisSlab / totalQty : 0;
          baseAmount = totalSubtotal * ratio;
          amount = baseAmount * (Number(slab.percentage) / 100);
        } else {
          amount = qtyInThisSlab * Number(slab.pricePerUnit);
        }

        lineItems.push({
          productType: isPercentage ? "NON_REUSABLE" : "REUSABLE",
          fromQty: slab.fromQty,
          toQty: slab.toQty,
          unitPrice: !isPercentage ? Number(slab.pricePerUnit) : null,
          percentage: isPercentage ? Number(slab.percentage) : null,
          baseAmount: isPercentage ? Number(baseAmount.toFixed(2)) : null,
          quantity: qtyInThisSlab,
          amount: Number(amount.toFixed(2)),
          slabId: slab.id,
        });

        remainingQty -= qtyInThisSlab;
      }

      return lineItems;
    };

    // 7. Calculate fees per active tariff period
    const allLineItems = [];

    for (const [dateStr, items] of Object.entries(orderItemsByDate)) {
      const deliveryDate = new Date(dateStr);
      const tariff = getTariffForDate(deliveryDate);

      if (!tariff) {
        throw new Error(`No tariff active on ${dateStr}`);
      }

      // Only calculate for items on this date
      const reusableQtyInPeriod = items
        .filter((i) => i.productType === "REUSABLE")
        .reduce((sum, i) => sum + i.quantity, 0);

      const nonReusableQtyInPeriod = items
        .filter((i) => i.productType === "NON_REUSABLE")
        .reduce((sum, i) => sum + i.quantity, 0);

      const nonReusableSubtotalInPeriod = items
        .filter((i) => i.productType === "NON_REUSABLE")
        .reduce((sum, i) => sum + Number(i.totalPrice), 0);

      // Apply tiering using **total period quantity**, but assign to correct tariff
      const reusableLines = calculateTieredFee(
        tariff.slabs,
        totalReusableQty,
        0,
        false
      );

      const nonReusableLines = calculateTieredFee(
        tariff.slabs,
        totalNonReusableQty,
        totalNonReusableSubtotal,
        true
      );

      // Tag lines with tariff info for audit
      [...reusableLines, ...nonReusableLines].forEach((line) => {
        line.tariffId = tariff.id;
        line.effectiveDate = deliveryDate;
        allLineItems.push(line);
      });
    }

    // 8. Deduplicate & merge same slab lines (optional, cleaner invoice)
    const mergedLineItems = allLineItems.reduce((acc, curr) => {
      const key = `${curr.productType}-${curr.fromQty}-${curr.toQty ?? "inf"}`;
      if (!acc[key]) {
        acc[key] = { ...curr };
      } else {
        acc[key].quantity += curr.quantity;
        acc[key].amount += curr.amount;
        if (curr.baseAmount) acc[key].baseAmount = (acc[key].baseAmount || 0) + curr.baseAmount;
      }
      return acc;
    }, {});

    const finalLineItems = Object.values(mergedLineItems).map((item) => ({
      productType: item.productType,
      fromQty: item.fromQty,
      toQty: item.toQty,
      unitPrice: item.unitPrice,
      percentage: item.percentage,
      baseAmount: item.baseAmount,
      quantity: item.quantity,
      amount: item.amount,
      tariffId: item.tariffId,
      slabId: item.slabId,
    }));

    const totalAmount = finalLineItems.reduce((sum, li) => sum + li.amount, 0);

    // 9. Create or update invoice (if not already paid)
    // We already checked for paid invoice at the beginning, so existingInvoice here is either:
    // - null (no invoice exists)
    // - exists but not paid (UNPAID, PARTIAL, OVERDUE)
    
    if (existingInvoice) {
      // Invoice exists but is not fully paid
      await tx.invoiceLineItem.deleteMany({ where: { invoiceId: existingInvoice.id } });

      const updatedInvoice = await tx.invoice.update({
        where: { id: existingInvoice.id },
        data: {
          totalAmount,
          generatedAt: new Date(),
          lineItems: { create: finalLineItems },
          // Do NOT set billingStatus here
        },
        include: { lineItems: true, payments: { where: { status: "PAID" } } },
      });

      // Immediately re-run status update (uses real payments)
      const finalInvoice = await updateInvoiceStatus(updatedInvoice.id, tx);

      return { 
        message: "Invoice updated & status refreshed", 
        invoice: finalInvoice 
      };
    } else {
      // No existing invoice, create new one
      const newInvoice = await tx.invoice.create({
        data: {
          companyId,
          periodStart,
          periodEnd,
          totalAmount,
          dueDate: new Date(periodEnd.getTime() + 15 * 24 * 60 * 60 * 1000), // +15 days
          billingStatus: "UNPAID",
          generatedAt: new Date(),
          lineItems: { create: finalLineItems },
        },
        include: { lineItems: true },
      });

      return { 
        message: "Invoice generated", 
        invoice: newInvoice 
      };
    }
  });
}

// Optional: Generate all invoices for previous month (run via cron on 1st)
async function generateAllMonthlyInvoices() {
  const now = new Date();
  const periodStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const periodEnd = new Date(now.getFullYear(), now.getMonth(), 0); // last day of previous month

  const companies = await prisma.tenant.findMany({
    where: { status: "active" },
    select: { id: true },
  });

  const results = [];
  for (const { id } of companies) {
    try {
      const result = await generateInvoiceForCompany(id, periodStart, periodEnd);
      results.push({ companyId: id, success: true, result });
    } catch (err) {
      results.push({ companyId: id, success: false, error: err.message });
    }
  }

  return results;
}


async function getInvoiceById(invoiceId) {
  return prisma.invoice.findUnique({
    where: { id: invoiceId },
    include: {
      lineItems: true,
      payments: {
        where: { status: "PAID" },
      },
      company: {
        select: {
          id: true,
          name: true,
          email: true,
        },
      },
    },
  });
}

/**
 * GET all invoices for a company
 */
async function getInvoicesByCompany(companyId, options = {}) {
  const {
    limit = 50,
    offset = 0,
    status,
    periodStart,
    periodEnd,
    sortBy = "generatedAt",
    sortOrder = "desc",
  } = options;

  const where = { companyId };

  if (status) {
    where.billingStatus = status;
  }

  if (periodStart && periodEnd) {
    where.OR = [
      {
        periodStart: { gte: new Date(periodStart) },
        periodEnd: { lte: new Date(periodEnd) },
      },
      // Also find invoices that overlap with the period
      {
        periodStart: { lte: new Date(periodEnd) },
        periodEnd: { gte: new Date(periodStart) },
      },
    ];
  }

  const [invoices, totalCount] = await Promise.all([
    prisma.invoice.findMany({
      where,
      include: {
        lineItems: true,
        payments: {
          where: { status: "PAID" },
        },
      },
      orderBy: { [sortBy]: sortOrder },
      skip: offset,
      take: limit,
    }),
    prisma.invoice.count({ where }),
  ]);

  // Calculate paid amount and updated status
  const processedInvoices = invoices.map((invoice) => {
    const totalPaid = invoice.payments.reduce(
      (sum, p) => sum + Number(p.amount || 0),
      0
    );
    const totalAmount = Number(invoice.totalAmount || 0);
    const dueAmount = totalAmount - totalPaid;

    let billingStatus = invoice.billingStatus;

    // Recalculate status for consistency
    if (totalPaid >= totalAmount) {
      billingStatus = "PAID";
    } else if (totalPaid > 0) {
      billingStatus = "PARTIAL";
    } else if (invoice.dueDate && new Date(invoice.dueDate) < new Date()) {
      billingStatus = "OVERDUE";
    }

    return {
      ...invoice,
      totalPaid,
      dueAmount,
      billingStatus, // Recalculated status
    };
  });

  return {
    invoices: processedInvoices,
    pagination: {
      total: totalCount,
      limit,
      offset,
      hasMore: offset + invoices.length < totalCount,
    },
  };
}

/**
 * GET invoice by company and period (without regeneration)
 */
async function getInvoiceByPeriod(companyId, periodStart, periodEnd) {
  return prisma.invoice.findFirst({
    where: {
      companyId,
      periodStart: new Date(periodStart),
      periodEnd: new Date(periodEnd),
    },
    include: {
      lineItems: true,
      payments: {
        where: { status: "PAID" },
      },
      company: {
        select: {
          id: true,
          name: true,
          email: true,
        },
      },
    },
  });
}


module.exports = {
  generateInvoiceForCompany,
  generateAllMonthlyInvoices,
  getInvoiceById,
  getInvoicesByCompany,
  getInvoiceByPeriod,
};