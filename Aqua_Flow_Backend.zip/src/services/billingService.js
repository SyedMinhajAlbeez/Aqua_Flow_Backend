const prisma = require("../prisma/client");

/**
 * Get billing overview for admin or company admin
 * - Fetches invoices with only successful payments
 * - Calculates accurate totalPaid from filtered payments
 * - Uses DB billingStatus as source of truth where possible
 */
async function getBillingOverview({ role, companyId }) {
  const invoiceWhere = {};

  // Role-based access control
  if (role === "COMPANY_ADMIN") {
    invoiceWhere.companyId = companyId;
  }

  const invoices = await prisma.invoice.findMany({
    where: invoiceWhere,
    include: {
      payments: {
        where: {
          status: "PAID", // Only count confirmed successful payments
        },
      },
      company: {
        select: { name: true },
      },
    },
    orderBy: { periodStart: "desc" },
  });

  return invoices.map((invoice) => {
    // Use only PAID payments for total (avoids counting pending/failed)
    const totalPaid = invoice.payments.reduce(
      (sum, p) => sum + Number(p.amount || 0),
      0
    );

    const totalAmount = Number(invoice.totalAmount || 0);
    const dueAmount = totalAmount - totalPaid;

    // Prefer DB value, but recalculate if needed (for consistency with payment flow)
    let billingStatus = invoice.billingStatus || "UNPAID";

    // Re-validate status based on latest data (defensive)
    if (totalPaid >= totalAmount) {
      billingStatus = "PAID";
    } else if (totalPaid > 0) {
      billingStatus = "PARTIAL";
    } else if (invoice.dueDate && new Date(invoice.dueDate) < new Date()) {
      billingStatus = "OVERDUE";
    }

    return {
      invoiceId: invoice.id,
      companyId: invoice.companyId,
      companyName: invoice.company?.name || "Unknown",
      periodStart: invoice.periodStart,
      periodEnd: invoice.periodEnd,
      totalAmount,
      totalPaid,
      dueAmount,
      billingStatus,
      dueDate: invoice.dueDate,
      generatedAt: invoice.generatedAt,
      paidAt: invoice.paidAt,
    };
  });
}

/**
 * Update invoice billing status based on all its payments
 * - Called after creating a new payment
 * - Uses only valid (PAID) payments for calculation
 * - Updates paidAmount and paidAt accurately
 */
async function updateInvoiceStatus(invoiceId,tx = null) {
  // Fetch invoice + all its payments
  const client = tx || prisma;
  const invoice = await prisma.invoice.findUnique({
    where: { id: invoiceId },
    include: {
      payments: {
        where: {
          status: "PAID", // Only successful payments count toward total
        },
      },
    },
  });

  if (!invoice) {
    throw new Error("Invoice not found");
  }

  // Calculate total paid from successful payments only
  const totalPaid = invoice.payments.reduce(
    (sum, p) => sum + Number(p.amount || 0),
    0
  );

  const totalAmount = Number(invoice.totalAmount || 0);

  // Determine correct status
  let newStatus = "UNPAID";

  if (totalPaid >= totalAmount) {
    newStatus = "PAID";
  } else if (totalPaid > 0) {
    newStatus = "PARTIAL";
  } else if (invoice.dueDate && new Date(invoice.dueDate) < new Date()) {
    newStatus = "OVERDUE";
  }

  // Update invoice with accurate values
  const updatedInvoice = await prisma.invoice.update({
    where: { id: invoiceId },
    data: {
      billingStatus: newStatus,
      paidAmount: totalPaid,                // accurate total from PAID payments
      paidAt: totalPaid > 0 ? new Date() : null,
    },
  });

  return updatedInvoice;
}


async function validatePaymentBeforeCreate(invoiceId, amount) {
  const invoice = await prisma.invoice.findUnique({
    where: { id: invoiceId },
    include: {
      payments: {
        where: { status: "PAID" },
        select: { amount: true },
      },
    },
  });

  if (!invoice) {
    throw new Error("Invoice not found");
  }

  const totalPaid = invoice.payments.reduce(
    (sum, p) => sum + Number(p.amount || 0),
    0
  );

  const totalAmount = Number(invoice.totalAmount || 0);
  const remainingDue = totalAmount - totalPaid;

  if (remainingDue <= 0) {
    throw new Error("Invoice is already fully paid");
  }

  if (Number(amount) > remainingDue + 0.01) { // small tolerance for floating point
    throw new Error(
      `Payment amount (${amount}) exceeds remaining due (${remainingDue.toFixed(2)})`
    );
  }

  return { invoice, remainingDue };
}

module.exports = {
  getBillingOverview,
  updateInvoiceStatus,
  validatePaymentBeforeCreate,
};