-- AlterTable
ALTER TABLE "Tariff" ADD COLUMN     "isDefault" BOOLEAN NOT NULL DEFAULT false;
