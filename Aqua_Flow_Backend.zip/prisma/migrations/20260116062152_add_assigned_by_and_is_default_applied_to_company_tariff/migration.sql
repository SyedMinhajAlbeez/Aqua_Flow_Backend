-- AlterTable
ALTER TABLE "Tariff" ADD COLUMN     "assignedBy" TEXT;
