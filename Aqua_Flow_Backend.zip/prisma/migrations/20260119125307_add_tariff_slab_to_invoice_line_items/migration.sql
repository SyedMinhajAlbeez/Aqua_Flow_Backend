-- AlterTable
ALTER TABLE "InvoiceLineItem" ADD COLUMN     "slabId" TEXT,
ADD COLUMN     "tariffId" TEXT;
