-- AlterTable
ALTER TABLE "InvoiceLineItem" ADD COLUMN     "effectiveDate" TIMESTAMP(3);
