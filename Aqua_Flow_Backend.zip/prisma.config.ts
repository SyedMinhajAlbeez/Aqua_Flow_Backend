// prisma.config.ts
import "dotenv/config";

export default {
  schema: "prisma/schema.prisma",
};